//
//  ViewController.m
//  YZTableCell
//
//  Created by cksj on 16/6/30.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import "ViewController.h"
#import "YZTableVC.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    [self performSelector:@selector(abc) withObject:nil afterDelay:1];
    
}

- (void)abc{
    YZTableVC * vc = [[YZTableVC alloc]init];
    [self presentViewController:vc animated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
