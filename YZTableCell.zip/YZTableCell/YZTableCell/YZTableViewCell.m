//
//  YZTableViewCell.m
//  YZTableCell
//
//  Created by cksj on 16/6/30.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import "YZTableViewCell.h"

@implementation YZTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createView];
    }
    return self;
}

- (void)createView{
    _rollVC = [[YZAdRollVC alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 80) didSelectAtItem:^(NSInteger item) {
        NSLog(@"-----点击了 %d 内容是 %@", (int)item, _rollVC.dataSource[item]);
    } cellWebImage:^BOOL(UIImageView *cellImageView, id content, UIView *cellContentView, NSInteger item) {
        
        if (!cellContentView.subviews.count) {
            UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 80, 80)];
            label.center = cellContentView.center;
            label.textAlignment = NSTextAlignmentCenter;
            label.tag = 10010;
            [cellContentView addSubview:label];
        }
        
        UILabel * label = (id)[cellContentView viewWithTag:10010];
        label.text = content;
        
        if (item == 0) {
            label.backgroundColor = [UIColor yellowColor];
        }else {
            label.backgroundColor = [UIColor cyanColor];
        }
        
        return YES;
    }];
    [self.contentView addSubview:_rollVC.rollView];
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
