//
//  YZTableViewCell.h
//  YZTableCell
//
//  Created by cksj on 16/6/30.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YZAdRollVC.h"

@interface YZTableViewCell : UITableViewCell

@property (nonatomic, strong) YZAdRollVC * rollVC;

@end
