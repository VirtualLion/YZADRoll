//
//  AppDelegate.h
//  YZTableCell
//
//  Created by cksj on 16/6/30.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

