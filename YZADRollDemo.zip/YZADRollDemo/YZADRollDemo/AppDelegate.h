//
//  AppDelegate.h
//  YZADRollDemo
//
//  Created by 韩云智 on 16/6/21.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

