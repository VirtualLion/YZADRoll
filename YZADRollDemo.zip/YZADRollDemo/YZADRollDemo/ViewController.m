//
//  ViewController.m
//  YZADRollDemo
//
//  Created by 韩云智 on 16/6/21.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import "ViewController.h"
#import "YZAdRollVC.h"

@interface ViewController ()

@end

@implementation ViewController{
    NSMutableArray * _dataSource;
    NSMutableArray * _mydata;
    YZAdRollVC * _vc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    _dataSource = [NSMutableArray array];
    _mydata = [NSMutableArray array];
    
    for (int i = 0; i <= 10; i++) {
        UIImage * image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg", i]];
        [_dataSource addObject:image];
    }
    
//    _vc = [[YZAdRollVC alloc]initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, 200) didSelectAtItem:^(NSInteger item) {
//        
//        NSLog(@"点击了第 %d 张图片", (int)item);
//    } cellWebImage:^BOOL(UIImageView *cellImageView, id content, UIView *cellContentView, NSInteger item) {
//        
//        [cellImageView setImage:content];
//        return YES;
//    }];
    _vc = [[YZAdRollVC alloc]initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, 200) didSelectAtItem:^(NSInteger item) {
        
        NSLog(@"点击了第 %d 张图片", (int)item);
    } cellWebImage:nil];

    _vc.isScrollWithSign = YES;
    _vc.timerOffset = 3;
    _vc.timerInterval = 1.5;
    [_vc letPageControlRun];
    [_vc letTimerRun];
    
    [self.view addSubview:_vc.rollView];
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
    [btn addTarget:self action:@selector(onBtn) forControlEvents:UIControlEventTouchUpInside];
    btn.center = self.view.center;
    
    [self.view addSubview:btn];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)onBtn{
    
    _vc.timerOffset = -_vc.timerOffset;
    if (_mydata.count < _dataSource.count) {
        [_mydata addObject:_dataSource[_mydata.count]];
        _vc.dataSource = _mydata;
    }else {
        [[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"没有更多数据" delegate:nil cancelButtonTitle:@"确认" otherButtonTitles:nil, nil] show];
    }
}

@end
